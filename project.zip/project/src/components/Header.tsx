import React from 'react';
import { 
  Save, 
  FileText, 
  Calculator, 
  PieChart, 
  Download,
  Upload,
  Settings,
  Plus,
  Search,
  Bell
} from 'lucide-react';

interface HeaderProps {
  onNewSheet: () => void;
  onSave: () => void;
  onExport: () => void;
  onImport: () => void;
}

const Header: React.FC<HeaderProps> = ({ onNewSheet, onSave, onExport, onImport }) => {
  return (
    <header className="bg-white border-b-2 border-gray-200 shadow-md">
      <div className="px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl flex items-center justify-center shadow-lg">
                <Calculator className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">AccounTech Pro</h1>
                <p className="text-xs text-gray-500">Professional Accounting Suite</p>
              </div>
            </div>
            
            <nav className="flex items-center space-x-4">
              <button className="flex items-center space-x-2 px-3 py-2 text-gray-700 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors">
                <FileText className="w-4 h-4" />
                <span className="text-sm font-medium">Reports</span>
              </button>
              <button className="flex items-center space-x-2 px-3 py-2 text-gray-700 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors">
                <PieChart className="w-4 h-4" />
                <span className="text-sm font-medium">Analytics</span>
              </button>
            </nav>
          </div>
          
          {/* Search bar */}
          <div className="flex-1 max-w-md mx-8">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search cells, formulas, or data..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
              />
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <button
              onClick={onNewSheet}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors shadow-sm font-medium"
            >
              <Plus className="w-4 h-4" />
              <span className="text-sm font-medium">New Sheet</span>
            </button>
            
            <div className="flex items-center space-x-2">
              <button
                onClick={onSave}
                className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                title="Save"
              >
                <Save className="w-5 h-5" />
              </button>
              <button
                onClick={onExport}
                className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                title="Export"
              >
                <Download className="w-5 h-5" />
              </button>
              <button
                onClick={onImport}
                className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                title="Import"
              >
                <Upload className="w-5 h-5" />
              </button>
              <button className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                <Bell className="w-5 h-5" />
              </button>
              <button className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                <Settings className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;