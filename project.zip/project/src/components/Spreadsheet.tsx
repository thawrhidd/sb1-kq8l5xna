import React, { useState, useCallback, useRef, useEffect } from 'react';
import { Cell, Sheet } from '../types';
import { getCellId, getColumnName, formatCurrency, evaluateFormula, isValidFormula } from '../utils/cellUtils';

interface SpreadsheetProps {
  sheet: Sheet;
  onCellChange: (cellId: string, value: string | number) => void;
  selectedCells: string[];
  onCellSelect: (cellId: string, isMultiSelect: boolean) => void;
}

const Spreadsheet: React.FC<SpreadsheetProps> = ({
  sheet,
  onCellChange,
  selectedCells,
  onCellSelect
}) => {
  const [editingCell, setEditingCell] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const ROWS = 50;
  const COLS = 26;

  // Handle keyboard navigation
  const handleKeyNavigation = useCallback((event: KeyboardEvent) => {
    if (selectedCells.length === 1 && !editingCell) {
      const [row, col] = selectedCells[0].split('-').map(Number);
      let newRow = row;
      let newCol = col;

      switch (event.key) {
        case 'ArrowUp':
          newRow = Math.max(0, row - 1);
          break;
        case 'ArrowDown':
          newRow = Math.min(ROWS - 1, row + 1);
          break;
        case 'ArrowLeft':
          newCol = Math.max(0, col - 1);
          break;
        case 'ArrowRight':
          newCol = Math.min(COLS - 1, col + 1);
          break;
        case 'Enter':
          newRow = Math.min(ROWS - 1, row + 1);
          break;
        case 'Tab':
          event.preventDefault();
          newCol = Math.min(COLS - 1, col + 1);
          break;
        case 'F2':
          event.preventDefault();
          handleCellDoubleClick(row, col);
          return;
        case 'Delete':
        case 'Backspace':
          onCellChange(selectedCells[0], '');
          return;
        default:
          return;
      }

      if (newRow !== row || newCol !== col) {
        event.preventDefault();
        onCellSelect(getCellId(newRow, newCol), false);
      }
    }
  }, [selectedCells, editingCell, onCellSelect, onCellChange]);

  useEffect(() => {
    document.addEventListener('keydown', handleKeyNavigation);
    return () => document.removeEventListener('keydown', handleKeyNavigation);
  }, [handleKeyNavigation]);

  const handleCellClick = useCallback((row: number, col: number, event: React.MouseEvent) => {
    const cellId = getCellId(row, col);
    const isMultiSelect = event.ctrlKey || event.metaKey;
    onCellSelect(cellId, isMultiSelect);
  }, [onCellSelect]);

  const handleCellDoubleClick = useCallback((row: number, col: number) => {
    const cellId = getCellId(row, col);
    const cell = sheet.cells[cellId];
    setEditingCell(cellId);
    setEditValue(cell?.formula || cell?.value?.toString() || '');
  }, [sheet.cells]);

  const handleEditSubmit = useCallback(() => {
    if (editingCell) {
      onCellChange(editingCell, editValue);
      setEditingCell(null);
      setEditValue('');
    }
  }, [editingCell, editValue, onCellChange]);

  const handleEditCancel = useCallback(() => {
    setEditingCell(null);
    setEditValue('');
  }, []);

  const handleKeyDown = useCallback((event: React.KeyboardEvent) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      handleEditSubmit();
      // Move to next row after editing
      if (selectedCells.length === 1) {
        const [row, col] = selectedCells[0].split('-').map(Number);
        const newRow = Math.min(ROWS - 1, row + 1);
        onCellSelect(getCellId(newRow, col), false);
      }
    } else if (event.key === 'Escape') {
      handleEditCancel();
    } else if (event.key === 'Tab') {
      event.preventDefault();
      handleEditSubmit();
      // Move to next column after editing
      if (selectedCells.length === 1) {
        const [row, col] = selectedCells[0].split('-').map(Number);
        const newCol = Math.min(COLS - 1, col + 1);
        onCellSelect(getCellId(row, newCol), false);
      }
    }
  }, [handleEditSubmit, handleEditCancel, selectedCells, onCellSelect]);

  useEffect(() => {
    if (editingCell && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [editingCell]);

  // Auto-start editing when typing
  useEffect(() => {
    const handleTyping = (event: KeyboardEvent) => {
      if (selectedCells.length === 1 && !editingCell && 
          !event.ctrlKey && !event.metaKey && !event.altKey &&
          event.key.length === 1 && event.key.match(/[a-zA-Z0-9=+\-*/.,$%]/) &&
          document.activeElement?.tagName !== 'INPUT') {
        const cellId = selectedCells[0];
        setEditingCell(cellId);
        setEditValue(event.key);
      }
    };

    document.addEventListener('keydown', handleTyping);
    return () => document.removeEventListener('keydown', handleTyping);
  }, [selectedCells, editingCell]);

  const renderCell = (row: number, col: number) => {
    const cellId = getCellId(row, col);
    const cell = sheet.cells[cellId];
    const isSelected = selectedCells.includes(cellId);
    const isEditing = editingCell === cellId;

    let displayValue = '';
    if (cell) {
      if (cell.type === 'currency' && typeof cell.value === 'number') {
        displayValue = formatCurrency(cell.value);
      } else if (cell.formula && !isEditing) {
        const result = evaluateFormula(cell.formula, sheet.cells);
        displayValue = cell.type === 'currency' ? formatCurrency(result) : result.toString();
      } else {
        displayValue = cell.value?.toString() || '';
      }
    }

    return (
      <div
        key={cellId}
        className={`relative border-r border-b border-gray-200 h-9 flex items-center px-2 cursor-cell transition-all duration-150 ${
          isSelected ? 'bg-blue-100 border-blue-400 ring-1 ring-blue-400' : 'bg-white hover:bg-blue-50'
        }`}
        onClick={(e) => handleCellClick(row, col, e)}
        onDoubleClick={() => handleCellDoubleClick(row, col)}
        style={{ 
          width: sheet.columns[col]?.width || 120,
          textAlign: cell?.style?.textAlign || 'left'
        }}
      >
        {isEditing ? (
          <input
            ref={inputRef}
            type="text"
            value={editValue}
            onChange={(e) => setEditValue(e.target.value)}
            onKeyDown={handleKeyDown}
            onBlur={handleEditSubmit}
            className="w-full h-full px-1 border-none outline-none bg-white text-sm shadow-sm"
          />
        ) : (
          <span className={`text-sm truncate select-none ${cell?.style?.fontWeight === 'bold' ? 'font-semibold' : ''}`}>
            {displayValue}
          </span>
        )}
        {isSelected && !isEditing && (
          <div className="absolute -bottom-0.5 -right-0.5 w-2 h-2 bg-blue-600 cursor-se-resize" />
        )}
      </div>
    );
  };

  return (
    <div ref={containerRef} className="flex-1 overflow-auto bg-gray-50" tabIndex={0}>
      <div className="inline-block min-w-full">
        {/* Header row */}
        <div className="flex sticky top-0 bg-gray-100 border-b-2 border-gray-300 z-10 shadow-sm">
          <div className="w-12 h-9 border-r border-gray-300 bg-gray-200 flex items-center justify-center">
            <span className="text-xs font-medium text-gray-500">#</span>
          </div>
          {Array.from({ length: COLS }, (_, col) => (
            <div
              key={col}
              className="h-9 border-r border-gray-300 bg-gray-100 flex items-center justify-center font-semibold text-sm text-gray-700 hover:bg-gray-200 transition-colors"
              style={{ width: sheet.columns[col]?.width || 120 }}
            >
              {getColumnName(col)}
            </div>
          ))}
        </div>

        {/* Data rows */}
        {Array.from({ length: ROWS }, (_, row) => (
          <div key={row} className="flex">
            <div className="w-12 h-9 border-r border-gray-300 bg-gray-100 flex items-center justify-center hover:bg-gray-200 transition-colors">
              <span className="text-xs font-semibold text-gray-600">{row + 1}</span>
            </div>
            {Array.from({ length: COLS }, (_, col) => renderCell(row, col))}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Spreadsheet;