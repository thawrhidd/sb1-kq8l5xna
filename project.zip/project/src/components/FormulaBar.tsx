import React, { useState, useEffect } from 'react';
import { Cell } from '../types';
import { getCellId, getColumnName } from '../utils/cellUtils';

interface FormulaBarProps {
  selectedCells: string[];
  cells: { [key: string]: Cell };
  onFormulaChange: (formula: string) => void;
}

const FormulaBar: React.FC<FormulaBarProps> = ({ selectedCells, cells, onFormulaChange }) => {
  const [formula, setFormula] = useState('');
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    if (selectedCells.length === 1) {
      const cellId = selectedCells[0];
      const cell = cells[cellId];
      setFormula(cell?.formula || cell?.value?.toString() || '');
    } else if (selectedCells.length > 1) {
      setFormula('');
    }
    setIsEditing(false);
  }, [selectedCells, cells]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onFormulaChange(formula);
    setIsEditing(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      // Reset to original value
      if (selectedCells.length === 1) {
        const cellId = selectedCells[0];
        const cell = cells[cellId];
        setFormula(cell?.formula || cell?.value?.toString() || '');
      }
      setIsEditing(false);
    }
  };

  const getCellReference = (cellId: string) => {
    const [row, col] = cellId.split('-').map(Number);
    return `${getColumnName(col)}${row + 1}`;
  };

  return (
    <div className="bg-white border-b-2 border-gray-200 px-6 py-3 shadow-sm">
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2">
          <span className="text-sm font-semibold text-gray-700">Cell:</span>
          <div className="px-3 py-1.5 bg-blue-50 border border-blue-200 rounded text-sm font-mono text-blue-800 min-w-[80px] text-center">
            {selectedCells.length === 1 ? getCellReference(selectedCells[0]) : 
             selectedCells.length > 1 ? `${selectedCells.length} cells` : 'None'}
          </div>
        </div>
        
        <div className="flex-1">
          <form onSubmit={handleSubmit} className="flex items-center space-x-2">
            <span className="text-sm font-semibold text-gray-700">fx</span>
            <input
              type="text"
              value={formula}
              onChange={(e) => {
                setFormula(e.target.value);
                setIsEditing(true);
              }}
              onKeyDown={handleKeyDown}
              onFocus={() => setIsEditing(true)}
              className="flex-1 px-3 py-2 border-2 border-gray-300 rounded-md text-sm font-mono focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
              placeholder="Enter formula or value..."
            />
            {isEditing && (
              <button
                type="submit"
                className="px-4 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700 transition-colors shadow-sm"
              >
                Apply
              </button>
            )}
            <button
              type="button"
              onClick={() => {
                if (selectedCells.length === 1) {
                  const cellId = selectedCells[0];
                  onFormulaChange('');
                }
              }}
              className="px-3 py-2 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-md text-sm transition-colors"
              title="Clear cell"
            >
              Clear
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default FormulaBar;