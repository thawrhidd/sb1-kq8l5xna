import React from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  DollarSign, 
  CreditCard, 
  FileText,
  PieChart,
  Calculator,
  Calendar
} from 'lucide-react';

const Sidebar: React.FC = () => {
  const menuItems = [
    { icon: BarChart3, label: 'Dashboard', active: true },
    { icon: DollarSign, label: 'Income', count: 12 },
    { icon: CreditCard, label: 'Expenses', count: 8 },
    { icon: TrendingUp, label: 'Profit & Loss' },
    { icon: PieChart, label: 'Budget Analysis' },
    { icon: FileText, label: 'Invoices', count: 5 },
    { icon: Calculator, label: 'Tax Calculator' },
    { icon: Calendar, label: 'Calendar' },
  ];

  return (
    <div className="w-64 bg-white border-r border-gray-200 h-full">
      <div className="p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Access</h2>
        <nav className="space-y-2">
          {menuItems.map((item, index) => (
            <a
              key={index}
              href="#"
              className={`flex items-center justify-between px-3 py-2 rounded-lg transition-colors ${
                item.active
                  ? 'bg-emerald-100 text-emerald-700'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <div className="flex items-center space-x-3">
                <item.icon className="w-5 h-5" />
                <span className="text-sm font-medium">{item.label}</span>
              </div>
              {item.count && (
                <span className="px-2 py-1 bg-gray-200 text-gray-700 rounded-full text-xs">
                  {item.count}
                </span>
              )}
            </a>
          ))}
        </nav>
      </div>
      
      <div className="p-6 border-t border-gray-200">
        <h3 className="text-sm font-semibold text-gray-900 mb-3">Recent Activity</h3>
        <div className="space-y-3">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-emerald-100 rounded-full flex items-center justify-center">
              <DollarSign className="w-4 h-4 text-emerald-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-900">Payment received</p>
              <p className="text-xs text-gray-500">2 minutes ago</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
              <CreditCard className="w-4 h-4 text-red-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-900">Expense added</p>
              <p className="text-xs text-gray-500">1 hour ago</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;