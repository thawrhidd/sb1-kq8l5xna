import React from 'react';
import { 
  Bold, 
  Italic, 
  Underline, 
  AlignLeft, 
  AlignCenter, 
  AlignRight,
  DollarSign,
  Percent,
  Hash,
  Palette,
  Copy,
  Scissors,
  Clipboard,
  Undo,
  Redo
} from 'lucide-react';

interface ToolbarProps {
  onFormatChange: (format: string) => void;
  selectedCells: string[];
}

const Toolbar: React.FC<ToolbarProps> = ({ onFormatChange, selectedCells }) => {
  const actionButtons = [
    { icon: Undo, action: 'undo', title: 'Undo (Ctrl+Z)' },
    { icon: Redo, action: 'redo', title: 'Redo (Ctrl+Y)' },
  ];

  const clipboardButtons = [
    { icon: Scissors, action: 'cut', title: 'Cut (Ctrl+X)' },
    { icon: Copy, action: 'copy', title: 'Copy (Ctrl+C)' },
    { icon: Clipboard, action: 'paste', title: 'Paste (Ctrl+V)' },
  ];
  const formatButtons = [
    { icon: Bold, action: 'bold', title: 'Bold' },
    { icon: Italic, action: 'italic', title: 'Italic' },
    { icon: Underline, action: 'underline', title: 'Underline' },
  ];

  const alignButtons = [
    { icon: AlignLeft, action: 'align-left', title: 'Align Left' },
    { icon: AlignCenter, action: 'align-center', title: 'Align Center' },
    { icon: AlignRight, action: 'align-right', title: 'Align Right' },
  ];

  const typeButtons = [
    { icon: Hash, action: 'number', title: 'Number' },
    { icon: DollarSign, action: 'currency', title: 'Currency' },
    { icon: Percent, action: 'percentage', title: 'Percentage' },
  ];

  return (
    <div className="bg-white border-b border-gray-200 px-6 py-3 shadow-sm">
      <div className="flex items-center space-x-4">
        {/* Action buttons */}
        <div className="flex items-center space-x-1">
          {actionButtons.map(({ icon: Icon, action, title }) => (
            <button
              key={action}
              onClick={() => onFormatChange(action)}
              className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-md transition-colors"
              title={title}
            >
              <Icon className="w-4 h-4" />
            </button>
          ))}
        </div>

        <div className="w-px h-6 bg-gray-300" />

        {/* Clipboard buttons */}
        <div className="flex items-center space-x-1">
          {clipboardButtons.map(({ icon: Icon, action, title }) => (
            <button
              key={action}
              onClick={() => onFormatChange(action)}
              className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-md transition-colors"
              title={title}
            >
              <Icon className="w-4 h-4" />
            </button>
          ))}
        </div>

        <div className="w-px h-6 bg-gray-300" />
        {/* Format buttons */}
        <div className="flex items-center space-x-1">
          {formatButtons.map(({ icon: Icon, action, title }) => (
            <button
              key={action}
              onClick={() => onFormatChange(action)}
              className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-md transition-colors"
              title={title}
            >
              <Icon className="w-4 h-4" />
            </button>
          ))}
        </div>

        <div className="w-px h-6 bg-gray-300" />

        {/* Alignment buttons */}
        <div className="flex items-center space-x-1">
          {alignButtons.map(({ icon: Icon, action, title }) => (
            <button
              key={action}
              onClick={() => onFormatChange(action)}
              className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-md transition-colors"
              title={title}
            >
              <Icon className="w-4 h-4" />
            </button>
          ))}
        </div>

        <div className="w-px h-6 bg-gray-300" />

        {/* Type buttons */}
        <div className="flex items-center space-x-1">
          {typeButtons.map(({ icon: Icon, action, title }) => (
            <button
              key={action}
              onClick={() => onFormatChange(action)}
              className={`p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-md transition-colors ${
                action === 'currency' ? 'bg-blue-50 text-blue-600' : ''
              }`}
              title={title}
            >
              <Icon className="w-4 h-4" />
            </button>
          ))}
        </div>

        <div className="w-px h-6 bg-gray-300" />

        {/* Color picker */}
        <button
          onClick={() => onFormatChange('color')}
          className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-md transition-colors"
          title="Text Color"
        >
          <Palette className="w-4 h-4" />
        </button>

        {/* Cell count */}
        <div className="ml-auto text-sm text-gray-500">
          {selectedCells.length > 0 && (
            <span className="px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-xs font-medium">
              {selectedCells.length} cell{selectedCells.length > 1 ? 's' : ''} selected
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

export default Toolbar;