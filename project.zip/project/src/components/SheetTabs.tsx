import React from 'react';
import { Sheet } from '../types';
import { X, Plus } from 'lucide-react';

interface SheetTabsProps {
  sheets: Sheet[];
  activeSheetId: string;
  onSheetSelect: (sheetId: string) => void;
  onSheetDelete: (sheetId: string) => void;
  onNewSheet: () => void;
}

const SheetTabs: React.FC<SheetTabsProps> = ({
  sheets,
  activeSheetId,
  onSheetSelect,
  onSheetDelete,
  onNewSheet
}) => {
  return (
    <div className="bg-gray-50 border-b border-gray-200 px-6 py-2">
      <div className="flex items-center space-x-2">
        {sheets.map((sheet) => (
          <div
            key={sheet.id}
            className={`group relative flex items-center space-x-2 px-4 py-2 rounded-t-lg cursor-pointer transition-all ${
              activeSheetId === sheet.id
                ? 'bg-white border-t-2 border-emerald-500 shadow-sm'
                : 'bg-gray-100 hover:bg-gray-200'
            }`}
            onClick={() => onSheetSelect(sheet.id)}
          >
            <span className="text-sm font-medium text-gray-900">{sheet.name}</span>
            {sheets.length > 1 && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onSheetDelete(sheet.id);
                }}
                className="p-1 opacity-0 group-hover:opacity-100 hover:bg-gray-300 rounded transition-opacity"
              >
                <X className="w-3 h-3 text-gray-500" />
              </button>
            )}
          </div>
        ))}
        
        <button
          onClick={onNewSheet}
          className="flex items-center space-x-2 px-3 py-2 text-gray-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span className="text-sm font-medium">Add Sheet</span>
        </button>
      </div>
    </div>
  );
};

export default SheetTabs;