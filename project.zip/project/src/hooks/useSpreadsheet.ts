import { useState, useCallback } from 'react';
import { Sheet, Cell } from '../types';
import { getCellId, isValidFormula } from '../utils/cellUtils';

export const useSpreadsheet = () => {
  const [sheets, setSheets] = useState<Sheet[]>([
    {
      id: 'sheet-1',
      name: 'Income Statement',
      cells: {
        '0-0': { id: '0-0', row: 0, col: 0, value: 'INCOME STATEMENT', type: 'text', style: { fontWeight: 'bold', textAlign: 'center' } },
        '1-0': { id: '1-0', row: 1, col: 0, value: 'For the Year Ended December 31, 2024', type: 'text', style: { textAlign: 'center' } },
        '3-0': { id: '3-0', row: 3, col: 0, value: 'REVENUE', type: 'text', style: { fontWeight: 'bold' } },
        '4-0': { id: '4-0', row: 4, col: 0, value: 'Sales Revenue', type: 'text' },
        '4-1': { id: '4-1', row: 4, col: 1, value: 125000, type: 'currency' },
        '5-0': { id: '5-0', row: 5, col: 0, value: 'Service Revenue', type: 'text' },
        '5-1': { id: '5-1', row: 5, col: 1, value: 75000, type: 'currency' },
        '6-0': { id: '6-0', row: 6, col: 0, value: 'Total Revenue', type: 'text', style: { fontWeight: 'bold' } },
        '6-1': { id: '6-1', row: 6, col: 1, value: 200000, type: 'currency', style: { fontWeight: 'bold' } },
        '8-0': { id: '8-0', row: 8, col: 0, value: 'EXPENSES', type: 'text', style: { fontWeight: 'bold' } },
        '9-0': { id: '9-0', row: 9, col: 0, value: 'Cost of Goods Sold', type: 'text' },
        '9-1': { id: '9-1', row: 9, col: 1, value: 80000, type: 'currency' },
        '10-0': { id: '10-0', row: 10, col: 0, value: 'Operating Expenses', type: 'text' },
        '10-1': { id: '10-1', row: 10, col: 1, value: 45000, type: 'currency' },
        '11-0': { id: '11-0', row: 11, col: 0, value: 'Total Expenses', type: 'text', style: { fontWeight: 'bold' } },
        '11-1': { id: '11-1', row: 11, col: 1, value: 125000, type: 'currency', style: { fontWeight: 'bold' } },
        '13-0': { id: '13-0', row: 13, col: 0, value: 'NET INCOME', type: 'text', style: { fontWeight: 'bold' } },
        '13-1': { id: '13-1', row: 13, col: 1, value: 75000, type: 'currency', style: { fontWeight: 'bold' } },
      },
      columns: Array.from({ length: 26 }, (_, i) => ({
        id: `col-${i}`,
        name: String.fromCharCode(65 + i),
        width: i === 0 ? 200 : 120,
        type: 'text' as const,
      })),
    },
    {
      id: 'sheet-2',
      name: 'Balance Sheet',
      cells: {
        '0-0': { id: '0-0', row: 0, col: 0, value: 'BALANCE SHEET', type: 'text', style: { fontWeight: 'bold', textAlign: 'center' } },
        '1-0': { id: '1-0', row: 1, col: 0, value: 'As of December 31, 2024', type: 'text', style: { textAlign: 'center' } },
        '3-0': { id: '3-0', row: 3, col: 0, value: 'ASSETS', type: 'text', style: { fontWeight: 'bold' } },
        '4-0': { id: '4-0', row: 4, col: 0, value: 'Current Assets', type: 'text', style: { fontWeight: 'bold' } },
        '5-0': { id: '5-0', row: 5, col: 0, value: 'Cash', type: 'text' },
        '5-1': { id: '5-1', row: 5, col: 1, value: 50000, type: 'currency' },
        '6-0': { id: '6-0', row: 6, col: 0, value: 'Accounts Receivable', type: 'text' },
        '6-1': { id: '6-1', row: 6, col: 1, value: 25000, type: 'currency' },
        '7-0': { id: '7-0', row: 7, col: 0, value: 'Inventory', type: 'text' },
        '7-1': { id: '7-1', row: 7, col: 1, value: 30000, type: 'currency' },
        '8-0': { id: '8-0', row: 8, col: 0, value: 'Total Current Assets', type: 'text', style: { fontWeight: 'bold' } },
        '8-1': { id: '8-1', row: 8, col: 1, value: 105000, type: 'currency', style: { fontWeight: 'bold' } },
        '10-0': { id: '10-0', row: 10, col: 0, value: 'Fixed Assets', type: 'text', style: { fontWeight: 'bold' } },
        '11-0': { id: '11-0', row: 11, col: 0, value: 'Equipment', type: 'text' },
        '11-1': { id: '11-1', row: 11, col: 1, value: 75000, type: 'currency' },
        '12-0': { id: '12-0', row: 12, col: 0, value: 'Total Assets', type: 'text', style: { fontWeight: 'bold' } },
        '12-1': { id: '12-1', row: 12, col: 1, value: 180000, type: 'currency', style: { fontWeight: 'bold' } },
      },
      columns: Array.from({ length: 26 }, (_, i) => ({
        id: `col-${i}`,
        name: String.fromCharCode(65 + i),
        width: i === 0 ? 200 : 120,
        type: 'text' as const,
      })),
    },
    {
      id: 'sheet-3',
      name: 'Cash Flow',
      cells: {
        '0-0': { id: '0-0', row: 0, col: 0, value: 'CASH FLOW STATEMENT', type: 'text', style: { fontWeight: 'bold', textAlign: 'center' } },
        '1-0': { id: '1-0', row: 1, col: 0, value: 'For the Year Ended December 31, 2024', type: 'text', style: { textAlign: 'center' } },
        '3-0': { id: '3-0', row: 3, col: 0, value: 'Operating Activities', type: 'text', style: { fontWeight: 'bold' } },
        '4-0': { id: '4-0', row: 4, col: 0, value: 'Net Income', type: 'text' },
        '4-1': { id: '4-1', row: 4, col: 1, value: 75000, type: 'currency' },
        '5-0': { id: '5-0', row: 5, col: 0, value: 'Depreciation', type: 'text' },
        '5-1': { id: '5-1', row: 5, col: 1, value: 10000, type: 'currency' },
        '6-0': { id: '6-0', row: 6, col: 0, value: 'Net Cash from Operations', type: 'text', style: { fontWeight: 'bold' } },
        '6-1': { id: '6-1', row: 6, col: 1, value: 85000, type: 'currency', style: { fontWeight: 'bold' } },
      },
      columns: Array.from({ length: 26 }, (_, i) => ({
        id: `col-${i}`,
        name: String.fromCharCode(65 + i),
        width: i === 0 ? 200 : 120,
        type: 'text' as const,
      })),
    },
  ]);

  const [activeSheetId, setActiveSheetId] = useState('sheet-1');
  const [selectedCells, setSelectedCells] = useState<string[]>(['0-0']);

  const activeSheet = sheets.find(sheet => sheet.id === activeSheetId) || sheets[0];

  const updateCell = useCallback((sheetId: string, cellId: string, value: string | number) => {
    setSheets(prev => prev.map(sheet => {
      if (sheet.id === sheetId) {
        const cell: Cell = {
          id: cellId,
          row: parseInt(cellId.split('-')[0]),
          col: parseInt(cellId.split('-')[1]),
          value,
          type: typeof value === 'number' ? 'currency' : 'text',
        };

        // Check if it's a formula
        if (typeof value === 'string' && isValidFormula(value)) {
          cell.formula = value;
          cell.type = 'formula';
        } else if (typeof value === 'string' && value.startsWith('$')) {
          cell.value = parseFloat(value.slice(1));
          cell.type = 'currency';
        } else if (typeof value === 'string' && !isNaN(parseFloat(value)) && isFinite(parseFloat(value))) {
          cell.value = parseFloat(value);
          cell.type = 'currency';
        }

        return {
          ...sheet,
          cells: {
            ...sheet.cells,
            [cellId]: cell,
          },
        };
      }
      return sheet;
    }));
  }, []);

  const addSheet = useCallback(() => {
    const newSheetId = `sheet-${sheets.length + 1}`;
    const newSheet: Sheet = {
      id: newSheetId,
      name: `Sheet ${sheets.length + 1}`,
      cells: {},
      columns: Array.from({ length: 26 }, (_, i) => ({
        id: `col-${i}`,
        name: String.fromCharCode(65 + i),
        width: 120,
        type: 'text' as const,
      })),
    };
    setSheets(prev => [...prev, newSheet]);
    setActiveSheetId(newSheetId);
  }, [sheets.length]);

  const deleteSheet = useCallback((sheetId: string) => {
    if (sheets.length > 1) {
      setSheets(prev => prev.filter(sheet => sheet.id !== sheetId));
      if (activeSheetId === sheetId) {
        setActiveSheetId(sheets.find(sheet => sheet.id !== sheetId)?.id || sheets[0].id);
      }
    }
  }, [sheets, activeSheetId]);

  const selectCell = useCallback((cellId: string, isMultiSelect: boolean) => {
    setSelectedCells(prev => {
      if (isMultiSelect) {
        return prev.includes(cellId) 
          ? prev.filter(id => id !== cellId)
          : [...prev, cellId];
      } else {
        return [cellId];
      }
    });
  }, []);

  return {
    sheets,
    activeSheet,
    activeSheetId,
    selectedCells,
    setActiveSheetId,
    updateCell,
    addSheet,
    deleteSheet,
    selectCell,
  };
};