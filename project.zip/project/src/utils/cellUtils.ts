import { Cell } from '../types';

export const getCellId = (row: number, col: number): string => {
  return `${row}-${col}`;
};

export const getColumnName = (col: number): string => {
  let result = '';
  while (col >= 0) {
    result = String.fromCharCode(65 + (col % 26)) + result;
    col = Math.floor(col / 26) - 1;
  }
  return result;
};

export const formatCurrency = (value: number): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(value);
};

export const evaluateFormula = (formula: string, cells: { [key: string]: Cell }): number => {
  try {
    // Simple formula evaluation - in production, use a proper expression parser
    const cleanFormula = formula.replace(/=/g, '').trim();
    
    // Handle SUM function
    if (cleanFormula.startsWith('SUM(') && cleanFormula.endsWith(')')) {
      const range = cleanFormula.slice(4, -1);
      const [start, end] = range.split(':');
      // Simple range evaluation for demo
      return 0;
    }
    
    // Handle basic arithmetic
    const result = eval(cleanFormula);
    return typeof result === 'number' ? result : 0;
  } catch {
    return 0;
  }
};

export const isValidFormula = (formula: string): boolean => {
  return formula.startsWith('=') && formula.length > 1;
};