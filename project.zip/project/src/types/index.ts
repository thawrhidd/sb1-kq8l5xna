export interface Cell {
  id: string;
  row: number;
  col: number;
  value: string | number;
  formula?: string;
  type: 'text' | 'number' | 'currency' | 'formula';
  style?: {
    backgroundColor?: string;
    color?: string;
    fontWeight?: string;
    textAlign?: 'left' | 'center' | 'right';
  };
}

export interface Sheet {
  id: string;
  name: string;
  cells: { [key: string]: Cell };
  columns: Column[];
}

export interface Column {
  id: string;
  name: string;
  width: number;
  type: 'text' | 'number' | 'currency' | 'date';
}

export interface AccountingTemplate {
  id: string;
  name: string;
  description: string;
  sheets: Sheet[];
}