import React from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import SheetTabs from './components/SheetTabs';
import Toolbar from './components/Toolbar';
import FormulaBar from './components/FormulaBar';
import Spreadsheet from './components/Spreadsheet';
import { useSpreadsheet } from './hooks/useSpreadsheet';

function App() {
  const {
    sheets,
    activeSheet,
    activeSheetId,
    selectedCells,
    setActiveSheetId,
    updateCell,
    addSheet,
    deleteSheet,
    selectCell,
  } = useSpreadsheet();

  const handleCellChange = (cellId: string, value: string | number) => {
    updateCell(activeSheetId, cellId, value);
  };

  const handleFormulaChange = (formula: string) => {
    if (selectedCells.length === 1) {
      handleCellChange(selectedCells[0], formula);
    }
  };

  const handleFormatChange = (format: string) => {
    // Handle formatting changes
    console.log('Format change:', format, 'for cells:', selectedCells);
  };

  const handleSave = () => {
    const data = JSON.stringify(sheets, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'accounting-data.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExport = () => {
    // Export to CSV
    const csvData = Object.entries(activeSheet.cells)
      .map(([cellId, cell]) => {
        const [row, col] = cellId.split('-').map(Number);
        return `${row},${col},"${cell.value}"`;
      })
      .join('\n');
    
    const blob = new Blob([csvData], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${activeSheet.name}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImport = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json,.csv';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          try {
            const data = JSON.parse(e.target?.result as string);
            // Handle imported data
            console.log('Imported data:', data);
          } catch (error) {
            console.error('Error importing data:', error);
          }
        };
        reader.readAsText(file);
      }
    };
    input.click();
  };

  return (
    <div className="h-screen bg-gray-50 flex flex-col">
      <Header 
        onNewSheet={addSheet}
        onSave={handleSave}
        onExport={handleExport}
        onImport={handleImport}
      />
      
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        
        <div className="flex-1 flex flex-col">
          <SheetTabs
            sheets={sheets}
            activeSheetId={activeSheetId}
            onSheetSelect={setActiveSheetId}
            onSheetDelete={deleteSheet}
            onNewSheet={addSheet}
          />
          
          <Toolbar
            onFormatChange={handleFormatChange}
            selectedCells={selectedCells}
          />
          
          <FormulaBar
            selectedCells={selectedCells}
            cells={activeSheet.cells}
            onFormulaChange={handleFormulaChange}
          />
          
          <Spreadsheet
            sheet={activeSheet}
            onCellChange={handleCellChange}
            selectedCells={selectedCells}
            onCellSelect={selectCell}
          />
        </div>
      </div>
    </div>
  );
}

export default App;