import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity, 
  TextInput, 
  Alert,
  Modal,
  Dimensions 
} from 'react-native';
import { Plus, CreditCard as Edit3, Trash2, Save, X, DollarSign } from 'lucide-react-native';
import { AccountingStorage, Sheet, SheetRow } from '@/utils/AccountingStorage';

const { width } = Dimensions.get('window');

interface SpreadsheetViewProps {
  sheetId: string;
  onDataChange?: () => void;
}

export default function SpreadsheetView({ sheetId, onDataChange }: SpreadsheetViewProps) {
  const [sheet, setSheet] = useState<Sheet | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingRow, setEditingRow] = useState<SheetRow | null>(null);
  const [newRow, setNewRow] = useState({
    description: '',
    amount: '',
    type: 'income' as 'income' | 'expense',
    category: '',
    reference: '',
  });

  useEffect(() => {
    loadSheet();
  }, [sheetId]);

  const loadSheet = async () => {
    try {
      const sheetData = await AccountingStorage.getSheet(sheetId);
      setSheet(sheetData);
    } catch (error) {
      console.error('Error loading sheet:', error);
    }
  };

  const handleAddRow = async () => {
    if (!newRow.description || !newRow.amount) {
      Alert.alert('Error', 'Please fill in description and amount');
      return;
    }

    try {
      await AccountingStorage.addRow(sheetId, {
        description: newRow.description,
        amount: parseFloat(newRow.amount),
        type: newRow.type,
        category: newRow.category,
        date: new Date().toISOString(),
        reference: newRow.reference,
      });

      setNewRow({
        description: '',
        amount: '',
        type: 'income',
        category: '',
        reference: '',
      });
      setShowAddModal(false);
      loadSheet();
      onDataChange?.();
    } catch (error) {
      console.error('Error adding row:', error);
      Alert.alert('Error', 'Failed to add entry');
    }
  };

  const handleUpdateRow = async () => {
    if (!editingRow) return;

    try {
      await AccountingStorage.updateRow(sheetId, editingRow.id, {
        description: newRow.description,
        amount: parseFloat(newRow.amount),
        type: newRow.type,
        category: newRow.category,
        reference: newRow.reference,
      });

      setEditingRow(null);
      setNewRow({
        description: '',
        amount: '',
        type: 'income',
        category: '',
        reference: '',
      });
      loadSheet();
      onDataChange?.();
    } catch (error) {
      console.error('Error updating row:', error);
      Alert.alert('Error', 'Failed to update entry');
    }
  };

  const handleDeleteRow = async (rowId: string) => {
    Alert.alert(
      'Delete Entry',
      'Are you sure you want to delete this entry?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await AccountingStorage.deleteRow(sheetId, rowId);
              loadSheet();
              onDataChange?.();
            } catch (error) {
              console.error('Error deleting row:', error);
              Alert.alert('Error', 'Failed to delete entry');
            }
          },
        },
      ]
    );
  };

  const startEditing = (row: SheetRow) => {
    setEditingRow(row);
    setNewRow({
      description: row.description,
      amount: row.amount.toString(),
      type: row.type,
      category: row.category,
      reference: row.reference || '',
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  const calculateTotals = () => {
    if (!sheet) return { income: 0, expenses: 0, balance: 0 };

    let income = 0;
    let expenses = 0;

    sheet.data.forEach(row => {
      if (row.type === 'income') {
        income += row.amount;
      } else {
        expenses += row.amount;
      }
    });

    return { income, expenses, balance: income - expenses };
  };

  const totals = calculateTotals();

  if (!sheet) {
    return (
      <View style={styles.loadingContainer}>
        <Text style={styles.loadingText}>Loading sheet...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.sheetName}>{sheet.name}</Text>
        <TouchableOpacity
          style={styles.addButton}
          onPress={() => setShowAddModal(true)}>
          <Plus size={20} color="#ffffff" />
          <Text style={styles.addButtonText}>Add Entry</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.summaryContainer}>
        <View style={styles.summaryItem}>
          <Text style={styles.summaryLabel}>Income</Text>
          <Text style={[styles.summaryValue, styles.incomeText]}>
            {formatCurrency(totals.income)}
          </Text>
        </View>
        <View style={styles.summaryItem}>
          <Text style={styles.summaryLabel}>Expenses</Text>
          <Text style={[styles.summaryValue, styles.expenseText]}>
            {formatCurrency(totals.expenses)}
          </Text>
        </View>
        <View style={styles.summaryItem}>
          <Text style={styles.summaryLabel}>Balance</Text>
          <Text style={[
            styles.summaryValue,
            totals.balance >= 0 ? styles.positiveBalance : styles.negativeBalance
          ]}>
            {formatCurrency(totals.balance)}
          </Text>
        </View>
      </View>

      <ScrollView style={styles.tableContainer}>
        <View style={styles.tableHeader}>
          <Text style={[styles.headerCell, styles.descriptionColumn]}>Description</Text>
          <Text style={[styles.headerCell, styles.amountColumn]}>Amount</Text>
          <Text style={[styles.headerCell, styles.typeColumn]}>Type</Text>
          <Text style={[styles.headerCell, styles.dateColumn]}>Date</Text>
          <Text style={[styles.headerCell, styles.actionsColumn]}>Actions</Text>
        </View>

        {sheet.data.length === 0 ? (
          <View style={styles.emptyState}>
            <DollarSign size={48} color="#cbd5e1" />
            <Text style={styles.emptyStateText}>No entries yet</Text>
            <Text style={styles.emptyStateSubtext}>Add your first accounting entry</Text>
          </View>
        ) : (
          sheet.data.map((row, index) => (
            <View key={row.id} style={[
              styles.tableRow,
              index % 2 === 0 ? styles.evenRow : styles.oddRow
            ]}>
              <Text style={[styles.cell, styles.descriptionColumn]}>{row.description}</Text>
              <Text style={[
                styles.cell,
                styles.amountColumn,
                row.type === 'income' ? styles.incomeText : styles.expenseText
              ]}>
                {formatCurrency(row.amount)}
              </Text>
              <Text style={[styles.cell, styles.typeColumn]}>
                {row.type === 'income' ? 'Income' : 'Expense'}
              </Text>
              <Text style={[styles.cell, styles.dateColumn]}>
                {formatDate(row.date)}
              </Text>
              <View style={[styles.cell, styles.actionsColumn]}>
                <TouchableOpacity
                  style={styles.actionButton}
                  onPress={() => startEditing(row)}>
                  <Edit3 size={14} color="#2563eb" />
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.actionButton}
                  onPress={() => handleDeleteRow(row.id)}>
                  <Trash2 size={14} color="#ef4444" />
                </TouchableOpacity>
              </View>
            </View>
          ))
        )}
      </ScrollView>

      <Modal
        visible={showAddModal || editingRow !== null}
        animationType="slide"
        transparent={true}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>
                {editingRow ? 'Edit Entry' : 'Add New Entry'}
              </Text>
              <TouchableOpacity
                onPress={() => {
                  setShowAddModal(false);
                  setEditingRow(null);
                  setNewRow({
                    description: '',
                    amount: '',
                    type: 'income',
                    category: '',
                    reference: '',
                  });
                }}>
                <X size={24} color="#64748b" />
              </TouchableOpacity>
            </View>

            <View style={styles.formContainer}>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Description</Text>
                <TextInput
                  style={styles.textInput}
                  value={newRow.description}
                  onChangeText={(text) => setNewRow({ ...newRow, description: text })}
                  placeholder="Enter description"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Amount</Text>
                <TextInput
                  style={styles.textInput}
                  value={newRow.amount}
                  onChangeText={(text) => setNewRow({ ...newRow, amount: text })}
                  placeholder="0.00"
                  keyboardType="numeric"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Type</Text>
                <View style={styles.typeSelector}>
                  <TouchableOpacity
                    style={[
                      styles.typeOption,
                      newRow.type === 'income' && styles.selectedType
                    ]}
                    onPress={() => setNewRow({ ...newRow, type: 'income' })}>
                    <Text style={[
                      styles.typeOptionText,
                      newRow.type === 'income' && styles.selectedTypeText
                    ]}>Income</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[
                      styles.typeOption,
                      newRow.type === 'expense' && styles.selectedType
                    ]}
                    onPress={() => setNewRow({ ...newRow, type: 'expense' })}>
                    <Text style={[
                      styles.typeOptionText,
                      newRow.type === 'expense' && styles.selectedTypeText
                    ]}>Expense</Text>
                  </TouchableOpacity>
                </View>
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Category</Text>
                <TextInput
                  style={styles.textInput}
                  value={newRow.category}
                  onChangeText={(text) => setNewRow({ ...newRow, category: text })}
                  placeholder="Enter category"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Reference (Optional)</Text>
                <TextInput
                  style={styles.textInput}
                  value={newRow.reference}
                  onChangeText={(text) => setNewRow({ ...newRow, reference: text })}
                  placeholder="Enter reference"
                />
              </View>
            </View>

            <View style={styles.modalActions}>
              <TouchableOpacity
                style={styles.cancelButton}
                onPress={() => {
                  setShowAddModal(false);
                  setEditingRow(null);
                  setNewRow({
                    description: '',
                    amount: '',
                    type: 'income',
                    category: '',
                    reference: '',
                  });
                }}>
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.saveButton}
                onPress={editingRow ? handleUpdateRow : handleAddRow}>
                <Save size={16} color="#ffffff" />
                <Text style={styles.saveButtonText}>
                  {editingRow ? 'Update' : 'Save'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#ffffff',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  sheetName: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1e293b',
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#2563eb',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 8,
  },
  addButtonText: {
    color: '#ffffff',
    fontWeight: '600',
    marginLeft: 8,
  },
  summaryContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: '#ffffff',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  summaryItem: {
    alignItems: 'center',
  },
  summaryLabel: {
    fontSize: 14,
    color: '#64748b',
    marginBottom: 4,
  },
  summaryValue: {
    fontSize: 16,
    fontWeight: '700',
  },
  incomeText: {
    color: '#10b981',
  },
  expenseText: {
    color: '#ef4444',
  },
  positiveBalance: {
    color: '#10b981',
  },
  negativeBalance: {
    color: '#ef4444',
  },
  tableContainer: {
    flex: 1,
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#f1f5f9',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  headerCell: {
    fontSize: 14,
    fontWeight: '600',
    color: '#475569',
  },
  tableRow: {
    flexDirection: 'row',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  evenRow: {
    backgroundColor: '#ffffff',
  },
  oddRow: {
    backgroundColor: '#f8fafc',
  },
  cell: {
    fontSize: 14,
    color: '#334155',
    textAlignVertical: 'center',
  },
  descriptionColumn: {
    width: width * 0.25,
  },
  amountColumn: {
    width: width * 0.2,
    textAlign: 'right',
  },
  typeColumn: {
    width: width * 0.15,
  },
  dateColumn: {
    width: width * 0.2,
  },
  actionsColumn: {
    width: width * 0.2,
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  actionButton: {
    padding: 4,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 80,
  },
  emptyStateText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#64748b',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyStateSubtext: {
    fontSize: 14,
    color: '#94a3b8',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    width: width * 0.9,
    maxHeight: '80%',
    padding: 20,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#1e293b',
  },
  formContainer: {
    marginBottom: 20,
  },
  inputGroup: {
    marginBottom: 16,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 8,
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: '#1e293b',
  },
  typeSelector: {
    flexDirection: 'row',
    gap: 8,
  },
  typeOption: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    alignItems: 'center',
  },
  selectedType: {
    backgroundColor: '#2563eb',
    borderColor: '#2563eb',
  },
  typeOptionText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#64748b',
  },
  selectedTypeText: {
    color: '#ffffff',
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 12,
  },
  cancelButton: {
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  cancelButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#64748b',
  },
  saveButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 8,
    backgroundColor: '#2563eb',
  },
  saveButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
    marginLeft: 8,
  },
});