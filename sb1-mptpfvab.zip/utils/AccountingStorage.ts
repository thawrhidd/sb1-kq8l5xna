import AsyncStorage from '@react-native-async-storage/async-storage';

export interface SheetRow {
  id: string;
  description: string;
  amount: number;
  type: 'income' | 'expense';
  category: string;
  date: string;
  reference?: string;
}

export interface Sheet {
  id: string;
  name: string;
  data: SheetRow[];
  createdAt: string;
  updatedAt: string;
}

const STORAGE_KEY = '@accounting_sheets';

export class AccountingStorage {
  static async getAllSheets(): Promise<Sheet[]> {
    try {
      const data = await AsyncStorage.getItem(STORAGE_KEY);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Error getting sheets:', error);
      return [];
    }
  }

  static async getSheet(sheetId: string): Promise<Sheet | null> {
    try {
      const sheets = await this.getAllSheets();
      return sheets.find(sheet => sheet.id === sheetId) || null;
    } catch (error) {
      console.error('Error getting sheet:', error);
      return null;
    }
  }

  static async createSheet(name: string): Promise<Sheet> {
    try {
      const newSheet: Sheet = {
        id: Date.now().toString(),
        name,
        data: [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      const sheets = await this.getAllSheets();
      sheets.push(newSheet);
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(sheets));
      
      return newSheet;
    } catch (error) {
      console.error('Error creating sheet:', error);
      throw error;
    }
  }

  static async updateSheet(sheetId: string, updates: Partial<Sheet>): Promise<void> {
    try {
      const sheets = await this.getAllSheets();
      const sheetIndex = sheets.findIndex(sheet => sheet.id === sheetId);
      
      if (sheetIndex === -1) {
        throw new Error('Sheet not found');
      }

      sheets[sheetIndex] = {
        ...sheets[sheetIndex],
        ...updates,
        updatedAt: new Date().toISOString(),
      };

      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(sheets));
    } catch (error) {
      console.error('Error updating sheet:', error);
      throw error;
    }
  }

  static async deleteSheet(sheetId: string): Promise<void> {
    try {
      const sheets = await this.getAllSheets();
      const filteredSheets = sheets.filter(sheet => sheet.id !== sheetId);
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(filteredSheets));
    } catch (error) {
      console.error('Error deleting sheet:', error);
      throw error;
    }
  }

  static async addRow(sheetId: string, row: Omit<SheetRow, 'id'>): Promise<SheetRow> {
    try {
      const sheet = await this.getSheet(sheetId);
      if (!sheet) {
        throw new Error('Sheet not found');
      }

      const newRow: SheetRow = {
        ...row,
        id: Date.now().toString(),
      };

      sheet.data.push(newRow);
      await this.updateSheet(sheetId, { data: sheet.data });
      
      return newRow;
    } catch (error) {
      console.error('Error adding row:', error);
      throw error;
    }
  }

  static async updateRow(sheetId: string, rowId: string, updates: Partial<SheetRow>): Promise<void> {
    try {
      const sheet = await this.getSheet(sheetId);
      if (!sheet) {
        throw new Error('Sheet not found');
      }

      const rowIndex = sheet.data.findIndex(row => row.id === rowId);
      if (rowIndex === -1) {
        throw new Error('Row not found');
      }

      sheet.data[rowIndex] = { ...sheet.data[rowIndex], ...updates };
      await this.updateSheet(sheetId, { data: sheet.data });
    } catch (error) {
      console.error('Error updating row:', error);
      throw error;
    }
  }

  static async deleteRow(sheetId: string, rowId: string): Promise<void> {
    try {
      const sheet = await this.getSheet(sheetId);
      if (!sheet) {
        throw new Error('Sheet not found');
      }

      sheet.data = sheet.data.filter(row => row.id !== rowId);
      await this.updateSheet(sheetId, { data: sheet.data });
    } catch (error) {
      console.error('Error deleting row:', error);
      throw error;
    }
  }

  static async exportData(): Promise<string> {
    try {
      const sheets = await this.getAllSheets();
      return JSON.stringify(sheets, null, 2);
    } catch (error) {
      console.error('Error exporting data:', error);
      throw error;
    }
  }

  static async importData(data: string): Promise<void> {
    try {
      const sheets = JSON.parse(data);
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(sheets));
    } catch (error) {
      console.error('Error importing data:', error);
      throw error;
    }
  }

  static async clearAllData(): Promise<void> {
    try {
      await AsyncStorage.removeItem(STORAGE_KEY);
    } catch (error) {
      console.error('Error clearing data:', error);
      throw error;
    }
  }
}