import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Delete, Percent, CirclePlus as PlusCircle, CircleMinus as MinusCircle } from 'lucide-react-native';

const { width } = Dimensions.get('window');
const buttonSize = (width - 80) / 4;

export default function CalculatorScreen() {
  const [display, setDisplay] = useState('0');
  const [previousValue, setPreviousValue] = useState<number | null>(null);
  const [operation, setOperation] = useState<string | null>(null);
  const [waitingForNewValue, setWaitingForNewValue] = useState(false);
  const [history, setHistory] = useState<string[]>([]);

  const inputNumber = (num: string) => {
    if (waitingForNewValue) {
      setDisplay(num);
      setWaitingForNewValue(false);
    } else {
      setDisplay(display === '0' ? num : display + num);
    }
  };

  const inputDecimal = () => {
    if (waitingForNewValue) {
      setDisplay('0.');
      setWaitingForNewValue(false);
    } else if (display.indexOf('.') === -1) {
      setDisplay(display + '.');
    }
  };

  const clear = () => {
    setDisplay('0');
    setPreviousValue(null);
    setOperation(null);
    setWaitingForNewValue(false);
  };

  const clearEntry = () => {
    setDisplay('0');
  };

  const performOperation = (nextOperation: string) => {
    const inputValue = parseFloat(display);

    if (previousValue === null) {
      setPreviousValue(inputValue);
    } else if (operation) {
      const currentValue = previousValue || 0;
      const newValue = calculate(currentValue, inputValue, operation);
      const result = newValue.toString();
      
      setDisplay(result);
      setPreviousValue(newValue);
      addToHistory(`${currentValue} ${operation} ${inputValue} = ${newValue}`);
    }

    setWaitingForNewValue(true);
    setOperation(nextOperation);
  };

  const calculate = (firstValue: number, secondValue: number, operation: string): number => {
    switch (operation) {
      case '+':
        return firstValue + secondValue;
      case '-':
        return firstValue - secondValue;
      case '×':
        return firstValue * secondValue;
      case '÷':
        return firstValue / secondValue;
      case '%':
        return firstValue % secondValue;
      default:
        return secondValue;
    }
  };

  const addToHistory = (calculation: string) => {
    setHistory(prev => [calculation, ...prev.slice(0, 9)]);
  };

  const formatNumber = (num: string) => {
    const number = parseFloat(num);
    if (number >= 1000000) {
      return (number / 1000000).toFixed(1) + 'M';
    } else if (number >= 1000) {
      return (number / 1000).toFixed(1) + 'K';
    }
    return num;
  };

  const Button = ({ 
    title, 
    onPress, 
    style, 
    textStyle, 
    icon 
  }: { 
    title?: string; 
    onPress: () => void; 
    style?: any; 
    textStyle?: any; 
    icon?: React.ReactNode;
  }) => (
    <TouchableOpacity 
      style={[styles.button, style]} 
      onPress={onPress}
      activeOpacity={0.7}>
      {icon ? icon : <Text style={[styles.buttonText, textStyle]}>{title}</Text>}
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Calculator</Text>
      </View>

      <View style={styles.historyContainer}>
        <Text style={styles.historyTitle}>History</Text>
        {history.length === 0 ? (
          <Text style={styles.noHistory}>No calculations yet</Text>
        ) : (
          history.slice(0, 3).map((calc, index) => (
            <Text key={index} style={styles.historyItem}>{calc}</Text>
          ))
        )}
      </View>

      <View style={styles.displayContainer}>
        <Text style={styles.display}>{formatNumber(display)}</Text>
        {operation && (
          <Text style={styles.operation}>
            {previousValue} {operation}
          </Text>
        )}
      </View>

      <View style={styles.buttonContainer}>
        <View style={styles.row}>
          <Button 
            title="C" 
            onPress={clear} 
            style={[styles.button, styles.clearButton]}
            textStyle={styles.clearButtonText}
          />
          <Button 
            title="CE" 
            onPress={clearEntry} 
            style={[styles.button, styles.clearButton]}
            textStyle={styles.clearButtonText}
          />
          <Button 
            onPress={() => performOperation('%')} 
            style={[styles.button, styles.operatorButton]}
            icon={<Percent size={24} color="#ffffff" />}
          />
          <Button 
            title="÷" 
            onPress={() => performOperation('÷')} 
            style={[styles.button, styles.operatorButton]}
            textStyle={styles.operatorButtonText}
          />
        </View>

        <View style={styles.row}>
          <Button title="7" onPress={() => inputNumber('7')} />
          <Button title="8" onPress={() => inputNumber('8')} />
          <Button title="9" onPress={() => inputNumber('9')} />
          <Button 
            title="×" 
            onPress={() => performOperation('×')} 
            style={[styles.button, styles.operatorButton]}
            textStyle={styles.operatorButtonText}
          />
        </View>

        <View style={styles.row}>
          <Button title="4" onPress={() => inputNumber('4')} />
          <Button title="5" onPress={() => inputNumber('5')} />
          <Button title="6" onPress={() => inputNumber('6')} />
          <Button 
            onPress={() => performOperation('-')} 
            style={[styles.button, styles.operatorButton]}
            icon={<MinusCircle size={24} color="#ffffff" />}
          />
        </View>

        <View style={styles.row}>
          <Button title="1" onPress={() => inputNumber('1')} />
          <Button title="2" onPress={() => inputNumber('2')} />
          <Button title="3" onPress={() => inputNumber('3')} />
          <Button 
            onPress={() => performOperation('+')} 
            style={[styles.button, styles.operatorButton]}
            icon={<PlusCircle size={24} color="#ffffff" />}
          />
        </View>

        <View style={styles.row}>
          <Button 
            title="0" 
            onPress={() => inputNumber('0')} 
            style={[styles.button, styles.zeroButton]}
          />
          <Button title="." onPress={inputDecimal} />
          <Button 
            title="=" 
            onPress={() => performOperation('=')} 
            style={[styles.button, styles.equalsButton]}
            textStyle={styles.equalsButtonText}
          />
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    padding: 20,
    paddingBottom: 10,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#1e293b',
  },
  historyContainer: {
    backgroundColor: '#ffffff',
    marginHorizontal: 20,
    marginBottom: 20,
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  historyTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1e293b',
    marginBottom: 12,
  },
  noHistory: {
    fontSize: 14,
    color: '#94a3b8',
    fontStyle: 'italic',
  },
  historyItem: {
    fontSize: 12,
    color: '#64748b',
    marginBottom: 4,
    fontFamily: 'monospace',
  },
  displayContainer: {
    backgroundColor: '#ffffff',
    marginHorizontal: 20,
    marginBottom: 20,
    borderRadius: 16,
    padding: 20,
    alignItems: 'flex-end',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  display: {
    fontSize: 36,
    fontWeight: '300',
    color: '#1e293b',
    fontFamily: 'monospace',
  },
  operation: {
    fontSize: 16,
    color: '#64748b',
    marginTop: 8,
    fontFamily: 'monospace',
  },
  buttonContainer: {
    paddingHorizontal: 20,
    flex: 1,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  button: {
    width: buttonSize,
    height: buttonSize,
    borderRadius: buttonSize / 2,
    backgroundColor: '#ffffff',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  buttonText: {
    fontSize: 24,
    fontWeight: '400',
    color: '#1e293b',
  },
  clearButton: {
    backgroundColor: '#f1f5f9',
  },
  clearButtonText: {
    color: '#64748b',
    fontSize: 18,
  },
  operatorButton: {
    backgroundColor: '#2563eb',
  },
  operatorButtonText: {
    color: '#ffffff',
    fontSize: 28,
  },
  equalsButton: {
    backgroundColor: '#10b981',
  },
  equalsButtonText: {
    color: '#ffffff',
    fontSize: 28,
  },
  zeroButton: {
    width: buttonSize * 2 + 12,
    borderRadius: buttonSize / 2,
  },
});