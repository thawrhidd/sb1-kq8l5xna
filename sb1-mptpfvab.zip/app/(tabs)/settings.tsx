import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, Switch } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Download, Upload, Trash2, Info, Shield, Palette, Bell, Globe, CircleHelp as HelpCircle } from 'lucide-react-native';
import { AccountingStorage } from '@/utils/AccountingStorage';

export default function SettingsScreen() {
  const [notifications, setNotifications] = useState(true);
  const [darkMode, setDarkMode] = useState(false);
  const [autoBackup, setAutoBackup] = useState(false);

  const exportData = async () => {
    try {
      const data = await AccountingStorage.exportData();
      Alert.alert(
        'Export Successful',
        'Your accounting data has been exported successfully.',
        [{ text: 'OK' }]
      );
    } catch (error) {
      console.error('Export error:', error);
      Alert.alert('Export Error', 'Failed to export data. Please try again.');
    }
  };

  const importData = async () => {
    Alert.alert(
      'Import Data',
      'This will replace all existing data. Are you sure you want to continue?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Import',
          style: 'destructive',
          onPress: async () => {
            try {
              // In a real app, you would use a file picker here
              Alert.alert('Import', 'File picker would open here');
            } catch (error) {
              console.error('Import error:', error);
              Alert.alert('Import Error', 'Failed to import data. Please try again.');
            }
          },
        },
      ]
    );
  };

  const clearAllData = async () => {
    Alert.alert(
      'Clear All Data',
      'This will permanently delete all your accounting sheets and data. This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Clear All',
          style: 'destructive',
          onPress: async () => {
            try {
              await AccountingStorage.clearAllData();
              Alert.alert('Success', 'All data has been cleared.');
            } catch (error) {
              console.error('Clear data error:', error);
              Alert.alert('Error', 'Failed to clear data. Please try again.');
            }
          },
        },
      ]
    );
  };

  const showAbout = () => {
    Alert.alert(
      'About Accounting Notepad',
      'Version 1.0.0\n\nA professional Excel-style accounting application for tracking income, expenses, and financial data.\n\nBuilt with React Native and Expo.',
      [{ text: 'OK' }]
    );
  };

  const showHelp = () => {
    Alert.alert(
      'Help & Support',
      'How to use the app:\n\n1. Create sheets for different accounts\n2. Add income and expense entries\n3. View your financial summary on the dashboard\n4. Use the calculator for quick calculations\n\nFor more help, visit our support page.',
      [{ text: 'OK' }]
    );
  };

  const SettingItem = ({ 
    icon, 
    title, 
    subtitle, 
    onPress, 
    showSwitch = false, 
    switchValue = false, 
    onSwitchChange,
    danger = false 
  }: {
    icon: React.ReactNode;
    title: string;
    subtitle?: string;
    onPress?: () => void;
    showSwitch?: boolean;
    switchValue?: boolean;
    onSwitchChange?: (value: boolean) => void;
    danger?: boolean;
  }) => (
    <TouchableOpacity 
      style={styles.settingItem} 
      onPress={onPress}
      disabled={showSwitch}>
      <View style={styles.settingLeft}>
        <View style={[styles.iconContainer, danger && styles.dangerIcon]}>
          {icon}
        </View>
        <View style={styles.settingText}>
          <Text style={[styles.settingTitle, danger && styles.dangerText]}>
            {title}
          </Text>
          {subtitle && (
            <Text style={styles.settingSubtitle}>{subtitle}</Text>
          )}
        </View>
      </View>
      {showSwitch && (
        <Switch
          value={switchValue}
          onValueChange={onSwitchChange}
          trackColor={{ false: '#e2e8f0', true: '#93c5fd' }}
          thumbColor={switchValue ? '#2563eb' : '#f4f4f5'}
        />
      )}
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <View style={styles.header}>
          <Text style={styles.title}>Settings</Text>
          <Text style={styles.subtitle}>Manage your app preferences</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Preferences</Text>
          <SettingItem
            icon={<Bell size={20} color="#2563eb" />}
            title="Notifications"
            subtitle="Receive reminders and updates"
            showSwitch
            switchValue={notifications}
            onSwitchChange={setNotifications}
          />
          <SettingItem
            icon={<Palette size={20} color="#2563eb" />}
            title="Dark Mode"
            subtitle="Switch to dark theme"
            showSwitch
            switchValue={darkMode}
            onSwitchChange={setDarkMode}
          />
          <SettingItem
            icon={<Shield size={20} color="#2563eb" />}
            title="Auto Backup"
            subtitle="Automatically backup your data"
            showSwitch
            switchValue={autoBackup}
            onSwitchChange={setAutoBackup}
          />
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Data Management</Text>
          <SettingItem
            icon={<Download size={20} color="#2563eb" />}
            title="Export Data"
            subtitle="Export all your accounting data"
            onPress={exportData}
          />
          <SettingItem
            icon={<Upload size={20} color="#2563eb" />}
            title="Import Data"
            subtitle="Import accounting data from file"
            onPress={importData}
          />
          <SettingItem
            icon={<Trash2 size={20} color="#ef4444" />}
            title="Clear All Data"
            subtitle="Delete all sheets and entries"
            onPress={clearAllData}
            danger
          />
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Support</Text>
          <SettingItem
            icon={<HelpCircle size={20} color="#2563eb" />}
            title="Help & Support"
            subtitle="Get help using the app"
            onPress={showHelp}
          />
          <SettingItem
            icon={<Globe size={20} color="#2563eb" />}
            title="Privacy Policy"
            subtitle="Read our privacy policy"
            onPress={() => Alert.alert('Privacy Policy', 'Privacy policy would open here')}
          />
          <SettingItem
            icon={<Info size={20} color="#2563eb" />}
            title="About"
            subtitle="App version and information"
            onPress={showAbout}
          />
        </View>

        <View style={styles.footer}>
          <Text style={styles.footerText}>
            Accounting Notepad v1.0.0
          </Text>
          <Text style={styles.footerSubtext}>
            Professional accounting made simple
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    padding: 20,
    paddingBottom: 10,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: '#64748b',
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1e293b',
    marginBottom: 16,
    marginHorizontal: 20,
  },
  settingItem: {
    backgroundColor: '#ffffff',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    marginHorizontal: 20,
    marginBottom: 2,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  dangerIcon: {
    backgroundColor: '#fef2f2',
  },
  settingText: {
    flex: 1,
  },
  settingTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1e293b',
    marginBottom: 2,
  },
  dangerText: {
    color: '#ef4444',
  },
  settingSubtitle: {
    fontSize: 14,
    color: '#64748b',
  },
  footer: {
    alignItems: 'center',
    padding: 40,
    paddingBottom: 20,
  },
  footerText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#64748b',
    marginBottom: 4,
  },
  footerSubtext: {
    fontSize: 12,
    color: '#94a3b8',
  },
});