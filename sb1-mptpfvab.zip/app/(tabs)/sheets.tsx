import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Plus, FileText, Trash2, CreditCard as Edit3, Search } from 'lucide-react-native';
import { AccountingStorage, Sheet } from '@/utils/AccountingStorage';
import { router } from 'expo-router';

export default function SheetsScreen() {
  const [sheets, setSheets] = useState<Sheet[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showNewSheetInput, setShowNewSheetInput] = useState(false);
  const [newSheetName, setNewSheetName] = useState('');

  const loadSheets = async () => {
    try {
      const allSheets = await AccountingStorage.getAllSheets();
      setSheets(allSheets);
    } catch (error) {
      console.error('Error loading sheets:', error);
    }
  };

  useEffect(() => {
    loadSheets();
  }, []);

  const createNewSheet = async () => {
    if (!newSheetName.trim()) {
      Alert.alert('Error', 'Please enter a sheet name');
      return;
    }

    try {
      const newSheet = await AccountingStorage.createSheet(newSheetName.trim());
      setSheets(prev => [...prev, newSheet]);
      setNewSheetName('');
      setShowNewSheetInput(false);
      router.push(`/sheet/${newSheet.id}`);
    } catch (error) {
      console.error('Error creating sheet:', error);
      Alert.alert('Error', 'Failed to create sheet');
    }
  };

  const deleteSheet = async (sheetId: string) => {
    Alert.alert(
      'Delete Sheet',
      'Are you sure you want to delete this sheet? This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await AccountingStorage.deleteSheet(sheetId);
              setSheets(prev => prev.filter(sheet => sheet.id !== sheetId));
            } catch (error) {
              console.error('Error deleting sheet:', error);
              Alert.alert('Error', 'Failed to delete sheet');
            }
          },
        },
      ]
    );
  };

  const filteredSheets = sheets.filter(sheet =>
    sheet.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  const calculateSheetSummary = (sheet: Sheet) => {
    let income = 0;
    let expenses = 0;
    
    sheet.data.forEach(row => {
      if (row.amount && typeof row.amount === 'number') {
        if (row.type === 'income') {
          income += row.amount;
        } else if (row.type === 'expense') {
          expenses += row.amount;
        }
      }
    });

    return { income, expenses, balance: income - expenses };
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Accounting Sheets</Text>
        <TouchableOpacity
          style={styles.addButton}
          onPress={() => setShowNewSheetInput(true)}>
          <Plus size={20} color="#ffffff" />
        </TouchableOpacity>
      </View>

      <View style={styles.searchContainer}>
        <Search size={20} color="#64748b" style={styles.searchIcon} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search sheets..."
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>

      {showNewSheetInput && (
        <View style={styles.newSheetContainer}>
          <TextInput
            style={styles.newSheetInput}
            placeholder="Enter sheet name"
            value={newSheetName}
            onChangeText={setNewSheetName}
            autoFocus
          />
          <View style={styles.newSheetActions}>
            <TouchableOpacity
              style={styles.cancelButton}
              onPress={() => {
                setShowNewSheetInput(false);
                setNewSheetName('');
              }}>
              <Text style={styles.cancelButtonText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.createButton}
              onPress={createNewSheet}>
              <Text style={styles.createButtonText}>Create</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      <ScrollView style={styles.sheetsContainer}>
        {filteredSheets.length === 0 ? (
          <View style={styles.emptyState}>
            <FileText size={48} color="#cbd5e1" />
            <Text style={styles.emptyStateText}>No sheets found</Text>
            <Text style={styles.emptyStateSubtext}>
              {searchQuery ? 'Try a different search term' : 'Create your first accounting sheet'}
            </Text>
          </View>
        ) : (
          filteredSheets.map((sheet) => {
            const summary = calculateSheetSummary(sheet);
            return (
              <TouchableOpacity
                key={sheet.id}
                style={styles.sheetCard}
                onPress={() => router.push(`/sheet/${sheet.id}`)}>
                <View style={styles.sheetHeader}>
                  <View style={styles.sheetInfo}>
                    <Text style={styles.sheetName}>{sheet.name}</Text>
                    <Text style={styles.sheetDate}>
                      Created {formatDate(sheet.createdAt)}
                    </Text>
                  </View>
                  <View style={styles.sheetActions}>
                    <TouchableOpacity
                      style={styles.actionButton}
                      onPress={() => router.push(`/sheet/${sheet.id}`)}>
                      <Edit3 size={16} color="#2563eb" />
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={styles.actionButton}
                      onPress={() => deleteSheet(sheet.id)}>
                      <Trash2 size={16} color="#ef4444" />
                    </TouchableOpacity>
                  </View>
                </View>
                
                <View style={styles.sheetSummary}>
                  <View style={styles.summaryItem}>
                    <Text style={styles.summaryLabel}>Income</Text>
                    <Text style={[styles.summaryValue, styles.incomeText]}>
                      {formatCurrency(summary.income)}
                    </Text>
                  </View>
                  <View style={styles.summaryItem}>
                    <Text style={styles.summaryLabel}>Expenses</Text>
                    <Text style={[styles.summaryValue, styles.expenseText]}>
                      {formatCurrency(summary.expenses)}
                    </Text>
                  </View>
                  <View style={styles.summaryItem}>
                    <Text style={styles.summaryLabel}>Balance</Text>
                    <Text style={[
                      styles.summaryValue,
                      summary.balance >= 0 ? styles.positiveBalance : styles.negativeBalance
                    ]}>
                      {formatCurrency(summary.balance)}
                    </Text>
                  </View>
                </View>
                
                <View style={styles.sheetFooter}>
                  <Text style={styles.entriesCount}>
                    {sheet.data.length} entries
                  </Text>
                  <Text style={styles.lastModified}>
                    Modified {formatDate(sheet.updatedAt)}
                  </Text>
                </View>
              </TouchableOpacity>
            );
          })
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    paddingBottom: 10,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#1e293b',
  },
  addButton: {
    backgroundColor: '#2563eb',
    borderRadius: 12,
    padding: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    marginHorizontal: 20,
    marginBottom: 20,
    paddingHorizontal: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  searchIcon: {
    marginRight: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    paddingVertical: 16,
    color: '#1e293b',
  },
  newSheetContainer: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    marginHorizontal: 20,
    marginBottom: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  newSheetInput: {
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
    color: '#1e293b',
  },
  newSheetActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 12,
  },
  cancelButton: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  cancelButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#64748b',
  },
  createButton: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
    backgroundColor: '#2563eb',
  },
  createButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
  },
  sheetsContainer: {
    flex: 1,
    paddingHorizontal: 20,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 80,
  },
  emptyStateText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#64748b',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyStateSubtext: {
    fontSize: 14,
    color: '#94a3b8',
    textAlign: 'center',
  },
  sheetCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  sheetHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  sheetInfo: {
    flex: 1,
  },
  sheetName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1e293b',
    marginBottom: 4,
  },
  sheetDate: {
    fontSize: 12,
    color: '#94a3b8',
  },
  sheetActions: {
    flexDirection: 'row',
    gap: 8,
  },
  actionButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: '#f1f5f9',
  },
  sheetSummary: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
  },
  summaryItem: {
    alignItems: 'center',
  },
  summaryLabel: {
    fontSize: 12,
    color: '#64748b',
    marginBottom: 4,
  },
  summaryValue: {
    fontSize: 14,
    fontWeight: '600',
  },
  incomeText: {
    color: '#10b981',
  },
  expenseText: {
    color: '#ef4444',
  },
  positiveBalance: {
    color: '#10b981',
  },
  negativeBalance: {
    color: '#ef4444',
  },
  sheetFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
  },
  entriesCount: {
    fontSize: 12,
    color: '#64748b',
  },
  lastModified: {
    fontSize: 12,
    color: '#94a3b8',
  },
});